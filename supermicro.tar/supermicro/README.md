



## Download from
https://www.supermicro.com/wdl/utility/SMCIPMItool/

## run with
java -jar SMCIPMITool.jar
java -jar SMCIPMITool.jar 192.168.1.2 ADMIN ADMINPASS
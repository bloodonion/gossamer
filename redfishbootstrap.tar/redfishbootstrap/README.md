

## Install of community requirements

- community.general requireds Ansible >=2.16.0

### To install

ansible-galaxy collection install collections-tarballs/community-general-*.tar.gz --offline -p ./collections


# Install OR

mkdir -p collections/ansible_collections/community/general
tar -xzf community-general-*.tar.gz -C collections/ansible_collections/community/general

### To install
In ansible.cfg
[defaults]
collections_paths = ./collections

https://sourcegraph.com/github.com/ansible/ansible-examples/-/blob/README.md